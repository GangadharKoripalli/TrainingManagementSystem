/**
 * 
 */
package com.virtusa.tms.dao;


import java.util.List;

import com.virtusa.tms.model.Course;
import com.virtusa.tms.model.Courses;
import com.virtusa.tms.model.Nomination;
import com.virtusa.tms.model.Venue;

/**
 * @author sheshareddy
 *
 */
public interface TrainingAdminDao {
	public boolean addVenue(String city, String address,String office);
	public boolean addCourse(String ccode, String cname, String clevel, String cvenue, String cdate);
	public List<Nomination> viewNominations();
	public boolean insertCourse(Course course);
	public List<Courses> uploadedCoures();
	public List<Venue> getOffice();
	public boolean deleteCourse(String ccode);
}
