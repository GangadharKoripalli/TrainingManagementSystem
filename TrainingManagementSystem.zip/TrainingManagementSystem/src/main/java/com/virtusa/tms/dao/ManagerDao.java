package com.virtusa.tms.dao;


import java.util.List;

import com.virtusa.tms.model.Courses;
import com.virtusa.tms.model.Nomination;

public interface ManagerDao {
	public List<Nomination> viewNominations();
	public boolean aprove(String empid,String ccode);
	public boolean reject(String empid,String ccode);
	public boolean insertCourse(String empid,String empname, String course, String level, String number);
}
