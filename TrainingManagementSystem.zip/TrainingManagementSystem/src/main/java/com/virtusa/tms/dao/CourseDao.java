package com.virtusa.tms.dao;

import java.util.ArrayList;

import com.virtusa.tms.model.Course;

public interface CourseDao {
	public boolean insertCourse(Course course);
	public ArrayList<Course> viewCourse();
	public boolean deleteCourse(String courseCode);
	/*public boolean updateCourse(String courseCode,String courseDesc,String skills,String courseDate,String courseTime);
	
	public ArrayList<Course> userViewCourse();
	public String courseDescription(String courseCode);
	public ArrayList<Course> searchCourse(String courseName);*/
}
