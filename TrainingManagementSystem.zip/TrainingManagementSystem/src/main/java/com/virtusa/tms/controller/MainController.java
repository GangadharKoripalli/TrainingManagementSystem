package com.virtusa.tms.controller;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.virtusa.tms.daoimpl.RegistrationDaoimpl;


@Controller
public class MainController {
	
	@RequestMapping(value = "/")
    public String startPage() {
        return "index";
    }
	
	@RequestMapping("/signin")
    public String loginPage() {
    	return "Login";
    }
    @RequestMapping("/LoginPage") 
    public String loginValidation(@RequestParam("u_id") String userId,@RequestParam("u_pass") String password,@RequestParam("u_type") String type,Model model,HttpSession session) {
    	RegistrationDaoimpl rService = new RegistrationDaoimpl();
    	System.out.println(userId);
    	System.out.println(password);
    	System.out.println(type);
    	if(type.equals("E")) {
    		if(rService.employeeLogin(userId, password)) {
    			System.out.println("welcome");
    			session.setAttribute("empid", userId);
    			return "employeeoperations";
    		} else {
    			System.out.println("not welcome");
    			
    		}
    	} 
    	
    	if(type.equals("A")) {
    		if(rService.trainingAdminLogin(userId, password)) {
    			System.out.println("welcome");
    			session.setAttribute("empid", userId);
    			return "taoperations";
    		} else {
    			System.out.println("not welcome");
    			
    		}
    	} 
    	if(type.equals("P")) {
    		if(rService.managerLogin(userId, password)) {
    			System.out.println("welcome");
    			session.setAttribute("empid", userId);
    			return "manageroperations";
    		} else {
    			System.out.println("not welcome");
    			
    		}
    	} 
    	return "index";
    }
}
