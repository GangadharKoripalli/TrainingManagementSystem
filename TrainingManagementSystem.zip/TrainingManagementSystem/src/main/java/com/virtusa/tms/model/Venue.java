package com.virtusa.tms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "venue_table")
public class Venue {
	@Column
	String city;
	@Column
	String address;
	@Id
	String office;
	public Venue(String city, String address, String office) {
		super();
		this.city = city;
		this.address = address;
		this.office = office;
	}
	public Venue() {
		super();
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
}
