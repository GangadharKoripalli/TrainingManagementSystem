package com.virtusa.tms.sqlQuery;

public interface EmployeeQueries {
	public static final String enroll= "insert into nomination(empid,ccode,cname,status) values(?,?,?,?)";
	public static final String cancelEnrollment="delete from nomination where empid=? and ccode=?";
	public static final String getStatus="select * from nomination where empid=?";
}
