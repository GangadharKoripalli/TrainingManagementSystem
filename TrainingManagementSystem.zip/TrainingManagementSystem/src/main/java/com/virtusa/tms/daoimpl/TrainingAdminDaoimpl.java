package com.virtusa.tms.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.tms.dao.TrainingAdminDao;

import com.virtusa.tms.hibernateUtils.HibernateUtils;
import com.virtusa.tms.model.Course;
import com.virtusa.tms.model.Courses;
import com.virtusa.tms.model.Employee;
import com.virtusa.tms.model.Nomination;
import com.virtusa.tms.model.Venue;
import com.virtusa.tms.sqlQuery.TrainingAdminQueries;
@Repository(value="TrainingAdminDao")
public class TrainingAdminDaoimpl implements TrainingAdminDao {
	
	public boolean addVenue(String city, String address, String office) {
		 Session session  = null;
		 Transaction transaction=null;
		 Venue data= new Venue(city, address, office);
		    try {
		      session =HibernateUtils.getSession();
		      transaction=session.beginTransaction();
		      session.save(data);
		      transaction.commit();
		    } catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		      if (session != null) {
		        session.close();
		      }
		    }
		return true;
	}
	public boolean insertCourse(Course course) {
		// TODO Auto-generated method stub
		return false;
	}
	@SuppressWarnings("unchecked")
	public List<Nomination> viewNominations() {
		// TODO Auto-generated method stub
		List<Nomination> results =null;
		 Session session  = HibernateUtils.getSession();
	        try {
	            session.getTransaction().begin();
	            String hql = " from Nomination E where E.status like 'a%'";
	            Query query = session.createQuery(hql);
	            results=query.list();
	           System.out.println(results);
	            /*List < EmployeeData > students = session.createQuery("FROM EmployeeData E WHERE E.id =:id").list();*/
	            /*students.forEach(s-> System.out.println(s.getFirstName()));*/
	            session.getTransaction().commit();
	            session.close();
	           }
	    catch(Exception ae) 
	        {
	    	System.out.println(ae);
	        }
	        return results;
	    }
	public List<Courses> uploadedCoures() {
		// TODO Auto-generated method stub
        Session sessFact =  HibernateUtils.getSession();
        sessFact.beginTransaction();
        Criteria criteria = sessFact.createCriteria(Courses.class);
        List<Courses> data= criteria.list();
        System.out.println(data.isEmpty());       
        sessFact.close();
        return (ArrayList<com.virtusa.tms.model.Courses>) data;
	}
	public boolean addCourse(String ccode, String cname, String clevel, String cvenue, String cdate) {
		// TODO Auto-generated method stub
		Session session  = null;
		 Transaction transaction=null;
		 Course course_details=new Course(ccode, cname, clevel, cvenue, cdate);
		    try {
		      session =HibernateUtils.getSession();
		      transaction=session.beginTransaction();
		      session.save(course_details);
		      transaction.commit();
		    } catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		      if (session != null) {
		        session.close();
		      }
		    }
		return true;
	}
	public List<Venue> getOffice() {
		// TODO Auto-generated method stub
		List<Venue> results =null;
		 Session session  = HibernateUtils.getSession();
		 
	        try {
	            session.getTransaction().begin();
	            String hql = " from  Venue";
	            Query query = session.createQuery(hql);
	            results=query.list();
	           System.out.println(results);
	            /*List < EmployeeData > students = session.createQuery("FROM EmployeeData E WHERE E.id =:id").list();*/
	            /*students.forEach(s-> System.out.println(s.getFirstName()));*/
	            session.getTransaction().commit();
	            session.close();
	           }
	    catch(Exception ae) 
	        {
	    	System.out.println(ae);
	        }
	        return results;
	}
	@Transactional 
	public boolean deleteCourse(String ccode) {
		// TODO Auto-generated method stub
		Transaction transaction=null;
		System.out.println(ccode);
		Session session  = HibernateUtils.getSession();
		transaction=session.beginTransaction();
		Query q=session.createQuery("delete from Course where ccode=:ccode");
		q.setParameter("ccode", ccode);
		q.executeUpdate();
		transaction.commit();
		
		return true;
		}
}
