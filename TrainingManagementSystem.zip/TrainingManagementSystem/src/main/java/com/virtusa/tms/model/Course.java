package com.virtusa.tms.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "course")
public class Course implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ccode;
	private String cname;
	private String clevel;
	private String cvenue;
	private String cdate;
		public Course() 
		{
		super();
		}
		public Course(String ccode, String cname, String clevel, String cvenue, String cdate) {
			super();
			this.ccode = ccode;
			this.cname = cname;
			this.clevel = clevel;
			this.cvenue = cvenue;
			this.cdate = cdate;
		}
		public Course(String ccode) {
			super();
			this.ccode = ccode;
		}
		@Id
		@Column
		public String getCcode() {
			return ccode;
		}
		public void setCcode(String ccode) {
			this.ccode = ccode;
		}
		@Column
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		@Column
		public String getClevel() {
			return clevel;
		}
		public void setClevel(String clevel) {
			this.clevel = clevel;
		}
		@Column
		public String getCvenue() {
			return cvenue;
		}
		public void setCvenue(String cvenue) {
			this.cvenue = cvenue;
		}
		@Column
		public String getCdate() {
			return cdate;
		}
		public void setCdate(String cdate) {
			this.cdate = cdate;
		}
}
