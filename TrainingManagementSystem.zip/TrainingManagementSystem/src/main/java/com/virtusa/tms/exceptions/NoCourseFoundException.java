package com.virtusa.tms.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND,reason=" User already logged in",code=HttpStatus.NOT_FOUND)
public class NoCourseFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public NoCourseFoundException() {
		super("No course found for logged in employee");
	}
}
