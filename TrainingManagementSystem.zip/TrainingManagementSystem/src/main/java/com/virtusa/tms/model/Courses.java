package com.virtusa.tms.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name = "courses")
public class Courses implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Id
@Column
private String empid;
@Column
private String empName;
@Column
private String course;
@Column
private String TierLevel;
@Column
private String mobileNumber;
		public Courses() {
			super();
		}
		
		public Courses(String empid, String empName, String course, String tierLevel, String mobileNumber) {
			super();
			this.empid = empid;
			this.empName = empName;
			this.course = course;
			TierLevel = tierLevel;
			this.mobileNumber = mobileNumber;
		}
		public String getEmpid() {
			return empid;
		}
		public void setEmpid(String empid) {
			this.empid = empid;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public String getTierLevel() {
			return TierLevel;
		}
		public void setTierLevel(String tierLevel) {
			TierLevel = tierLevel;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		
}
