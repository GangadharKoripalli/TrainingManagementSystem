package com.virtusa.tms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.tms.dao.TrainingAdminDao;
import com.virtusa.tms.daoimpl.TrainingAdminDaoimpl;
import com.virtusa.tms.exceptions.NoNominationAprroved;
import com.virtusa.tms.model.Nomination;
@Controller
public class TrainingAdminController {
	TrainingAdminDao tDao=new TrainingAdminDaoimpl();
	@RequestMapping("/back")
	public String trainingAdminHome()
	{
		return "taoperations";
	}
	@RequestMapping("/addvenue")
	public String addvenue() {
		return "addvenue";
	}
	@RequestMapping(value = { "/addvenue" }, method = RequestMethod.POST)
	public String addVenueDetails(@RequestParam("city") String city,@RequestParam("address") String address,@RequestParam("office") String  office,Model model,HttpSession session)
	{
		tDao.addVenue(city, address, office);
		return "welcome";
	}
	@RequestMapping("/logout")
	public String logout(HttpSession session)
	{
		session.removeAttribute("empid");
		session.invalidate();
		return "index";
	}
	@RequestMapping("/approvedNomination")
	public ModelAndView approvedNominationsList()
	{
		ModelAndView model=new ModelAndView("approvedNominations");
		   
		    model.addObject("EmployeeData",new TrainingAdminDaoimpl().viewNominations());
		    return model;
	}
	@RequestMapping("/courses")
	public ModelAndView employeeAndManagerPostedCourses()
	{
		ModelAndView model=new ModelAndView("uploadCourses");
		model.addObject("coursedata",new TrainingAdminDaoimpl().uploadedCoures());
		return model;
		
	}
	@RequestMapping("/upload")
	public String uploadcourse()
	{
		return "courseAdd";
	}
	@RequestMapping(value = { "/upload" }, method = RequestMethod.POST)
	public String courseUpload(@RequestParam("courseCode") String courseCode,@RequestParam("courseName") String courseName,@RequestParam("level") String level,@RequestParam("venue") String venue,@RequestParam("date") String date)
	{
		tDao.addCourse(courseCode, courseName, level, venue, date);
		return "successfulPostCourse";
	}
	@RequestMapping("/delete")
	public String deletecourse()
	{
		return "deleteCouse";
	}
	@RequestMapping(value = { "/delete" }, method = RequestMethod.POST)
	public String confirmDelete(@RequestParam("ccode") String ccode)
	{
		System.out.println("welcome"+ccode);
		tDao.deleteCourse(ccode);
		return "successfulDeleteCourse";
	}
}
