package com.virtusa.tms.sqlQuery;

public interface TrainingAdminQueries {
	public static final String addVenue = "insert into venue_table(city,address,office) values(?,?,?)";
	public static final String confirmNominations="select * from nomination where status=?";
}
