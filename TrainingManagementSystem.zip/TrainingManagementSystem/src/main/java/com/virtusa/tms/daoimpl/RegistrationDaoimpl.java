package com.virtusa.tms.daoimpl;


import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.virtusa.tms.dao.RegistrationDao;
import com.virtusa.tms.exceptions.NoCourseFoundException;
import com.virtusa.tms.hibernateUtils.HibernateUtils;
import com.virtusa.tms.model.Employee;
import com.virtusa.tms.model.Manager;
import com.virtusa.tms.model.TrainingAdmin;

@Repository(value="RegistrationDao")
public class RegistrationDaoimpl implements RegistrationDao {
	

	public boolean employeeLogin(String emp_id, String emp_password) {
		 Session session  = HibernateUtils.getSession();
		 session.beginTransaction();
		 Employee data= (Employee) session.load("com.virtusa.tms.model.Employee",emp_id);
		 String empid=data.getEmp_id();
		 String epass=data.getEmp_password();
		 System.out.println(empid);
		 System.out.println(epass);
		 if(emp_id.equals(empid)  && epass.equals(emp_password))
			 return true;
		 session.getTransaction().commit();
		 return false;
	}

	
	public boolean managerLogin(String emp_id, String emp_password) {
		// TODO Auto-generated method stub
		 Session session  = HibernateUtils.getSession();
		 session.beginTransaction();
		 Manager data= (Manager) session.load("com.virtusa.tms.model.Manager",emp_id);
		 String empid=data.getEmp_id();
		 String epass=data.getEmp_password();
		 System.out.println(empid);
		 System.out.println(epass);
		 if(emp_id.equals(empid)  && epass.equals(emp_password))
			 return true;
		 session.getTransaction().commit();
		 return false;
	}

	
	public boolean trainingAdminLogin(String emp_id, String emp_password) {
		// TODO Auto-generated method stub
		 Session session  = HibernateUtils.getSession();
		 session.beginTransaction();
		 TrainingAdmin data= (TrainingAdmin) session.load("com.virtusa.tms.model.TrainingAdmin",emp_id);
		 String empid=data.getEmp_id();
		 String epass=data.getEmp_password();
		 System.out.println(empid);
		 System.out.println(epass);
		 if(emp_id.equals(empid)  && epass.equals(emp_password))
			 return true;
		 session.getTransaction().commit();
		 return false;
	}

	public String getName(String m_userid) {
		// TODO Auto-generated method stub
		return null;
	}
}
