package com.virtusa.tms.dao;

public interface RegistrationDao {
	public boolean employeeLogin(String user_id, String password);
	public boolean managerLogin(String user_id, String password);
	public boolean trainingAdminLogin(String user_id, String password);
	public String getName(String m_userid);
}
