package com.virtusa.tms.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.tms.dao.ManagerDao;
import com.virtusa.tms.daoimpl.ManagerDaoimpl;
@Controller
public class ManagerController {
	ManagerDao mDao=new ManagerDaoimpl();
	@RequestMapping("/mback")
	public String trainingAdminHome()
	{
		return "manageroperations";
	}
	@RequestMapping("/mupload")
	public String uploadcourse()
	{
		return "managerCourseUpload";
	}
	@RequestMapping(value = { "/mupload" }, method = RequestMethod.POST)
	public String courseUpload(@RequestParam("empname") String empname,@RequestParam("course") String course,@RequestParam("level") String level,@RequestParam("number") String number,HttpSession session)
	{
		String empid=(String)session.getAttribute("empid");
		mDao.insertCourse(empid, empname, course, level, number);
		return "successfulPostCourse";
	}
	@RequestMapping("/mapprove")
	public String approve()
	{
		return "approveNotification";
	}
	@RequestMapping(value = { "/mapprove" }, method = RequestMethod.POST)
	public String confirmapprove(@RequestParam("empid") String empid,@RequestParam("ccode") String ccode)
	{
		System.out.println(empid+""+ccode);
		mDao.aprove(empid, ccode);
		return "approveNotification";
	}
	@RequestMapping(value = { "/mreject" }, method = RequestMethod.POST)
	public String confirmreject(@RequestParam("empid") String empid,@RequestParam("ccode") String ccode)
	{
		System.out.println(empid+""+ccode);
		mDao.reject(empid, ccode);
		return "approveNotification";
	}
	@RequestMapping("/mlogout")
	public String logout(HttpSession session)
	{
		session.removeAttribute("empid");
		session.invalidate();
		return "index";
	}
}
