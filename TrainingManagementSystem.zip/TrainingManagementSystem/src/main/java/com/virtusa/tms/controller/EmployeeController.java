package com.virtusa.tms.controller;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.virtusa.tms.dao.CourseDao;
import com.virtusa.tms.dao.EmployeeDao;
import com.virtusa.tms.dao.PostCourseDao;
import com.virtusa.tms.daoimpl.CourseDaoimpl;
import com.virtusa.tms.daoimpl.EmployeeDaoimpl;
import com.virtusa.tms.daoimpl.PostCourseDaoimpl;
import com.virtusa.tms.exceptions.NoCourseFoundException;
import com.virtusa.tms.exceptions.NoStatusFoundException;
import com.virtusa.tms.exceptions.UnSuccessfulPostCourse;
import com.virtusa.tms.exceptions.UnacleToCancelNomination;
import com.virtusa.tms.model.Course;
import com.virtusa.tms.model.Nomination;
@Controller
public class EmployeeController {
	EmployeeDao eDao= new EmployeeDaoimpl();
    @RequestMapping("/eback")
    public String home(Model model) {
        return "employeeoperations";
    }
    
    @RequestMapping("/viewCourse")
    public String viewCourse(Model model) {
        ArrayList<Course> cList=new ArrayList<Course>();
         
        cList = eDao.viewCourse();
        if(cList.size() > 0) {
        model.addAttribute("cList",cList);
        }
        else 
        {
            throw new NoCourseFoundException();
            
        }
        return "viewCourse";
    }
    @RequestMapping(value = { "/viewCourse" }, method = RequestMethod.POST)
    public String confirmCourse(@RequestParam("cCode") String cCode,@RequestParam("cName") String cName,@RequestParam("empname") String empname,HttpSession session)
    {
    	String empid=(String)session.getAttribute("empid");
    	eDao.enroll(empid, cCode, cName,empname);
    	return "successfullyEnroll";
    }
    @RequestMapping("/status")
    public ModelAndView approvestatus(HttpSession session) {
        String empid =(String) session.getAttribute("empid");
        //EmployeeDao eDao = new EmployeeDaoimpl();
        //cList=eDao.getStatus(empid);
        ModelAndView model = new ModelAndView("aprovestatus");
        model.addObject("EmployeeData",new EmployeeDaoimpl().getStatus(empid));
    
        return model;
    }
    @RequestMapping("/PostCourse")
    public String postCource()
    {
    	return "courseUpload";
    }
    @RequestMapping(value = { "/PostCourse" }, method = RequestMethod.POST)
    public String couseupload(@RequestParam("empname") String empname,@RequestParam("course") String course,@RequestParam("level") String level,@RequestParam("number") String number,HttpSession session) {
        String empid = (String)session.getAttribute("empid");
        try {
                if(eDao.insertCourse(empid, empname, course,level,number))
                {
                    return "successfulPostCourse";
                }
                else
                {
                    throw new UnSuccessfulPostCourse();
                }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return " ";
    }
    @RequestMapping("/cancelNomination")
    public String cancelNomination(Model model,HttpSession session) {
        ArrayList<Nomination> cList=new ArrayList<Nomination>();
        String empid=(String)session.getAttribute("empid");
        cList = eDao.enrolledCourses(empid);
            if(cList.size() > 0) {
                model.addAttribute("cList",cList);
            }
            else {
                throw new NoCourseFoundException();
            }
        
        return "CancelNomination";
    }
    
    
    @RequestMapping("/deleteNomination")
    public ModelAndView deleteNomination(HttpSession session,@RequestParam("ccode") String ccode)
    {
        String empid =(String) session.getAttribute("empid");
        ModelAndView model = new ModelAndView("NominationDeleted");
        model.addObject("cList",new EmployeeDaoimpl().cancelEnrollment(empid,ccode));
        return model;
    }

 

    
    @RequestMapping("/elogout")
    public String logout(HttpSession session)
    {
        session.removeAttribute("empid");
        session.invalidate();
        return "index";
    }
    
}