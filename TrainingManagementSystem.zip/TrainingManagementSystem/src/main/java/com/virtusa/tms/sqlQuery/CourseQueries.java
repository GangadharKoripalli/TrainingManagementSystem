package com.virtusa.tms.sqlQuery;

public interface CourseQueries {
	public static final String insertCourse="insert into course values(?,?,?,?,?)";
	public static final String viewCourse="select * from course order by ccode";
	public static final String deleteCourse="delete from course where ccode=? ";
}
