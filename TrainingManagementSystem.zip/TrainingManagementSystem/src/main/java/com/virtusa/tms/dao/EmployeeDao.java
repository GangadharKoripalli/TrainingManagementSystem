package com.virtusa.tms.dao;

import java.util.ArrayList;

import com.virtusa.tms.model.Course;
import com.virtusa.tms.model.Nomination;

public interface EmployeeDao {
	public boolean enroll(String empid,String ccode,String cname,String empname);
	public boolean cancelEnrollment(String empid,String ccode);
	public ArrayList<Nomination> getStatus(String empid);
	public ArrayList<Course> viewCourse();
	public boolean insertCourse(String empid, String empName, String course, String TierLevel, String mobileNumber);
	public ArrayList<Nomination> enrolledCourses(String empid);
}
