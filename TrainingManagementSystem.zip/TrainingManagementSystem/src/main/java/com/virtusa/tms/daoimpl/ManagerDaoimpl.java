package com.virtusa.tms.daoimpl;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.virtusa.tms.dao.ManagerDao;

import com.virtusa.tms.hibernateUtils.HibernateUtils;
import com.virtusa.tms.model.Course;
import com.virtusa.tms.model.Courses;
import com.virtusa.tms.model.Nomination;
import com.virtusa.tms.model.Venue;
import com.virtusa.tms.sqlQuery.ManagerQueries;
@Repository(value="ManagerDao")
public class ManagerDaoimpl implements ManagerDao {

	public List<Nomination> viewNominations() {
		// TODO Auto-generated method
		String status="pending";
		List<Nomination> results =null;
		 Session session  = HibernateUtils.getSession();
		 
	        try {
	            session.getTransaction().begin();
	            String hql = " from  Nomination where status=:status";
	            Query query = session.createQuery(hql);
	            query.setParameter("status",status);
	            results=query.list();
	           System.out.println(results);
	            session.getTransaction().commit();
	            session.close();
	           }
	    catch(Exception ae) 
	        {
	    	System.out.println(ae);
	        }
	        return results;
	}

	public boolean aprove(String empid, String ccode) {
		// TODO Auto-generated method stub
		System.out.println(empid+""+ccode);
		 Session session  = HibernateUtils.getSession();
		 
	        try {
	            session.getTransaction().begin();
	            String hql ="update Nomination set status='accepted' where empid=:empid and ccode=:ccode";
	            Query query = session.createQuery(hql);
	            query.setParameter("empid",empid);
	            query.setParameter("ccode", ccode);
	            System.out.print(query.executeUpdate());
	            session.getTransaction().commit();
	            session.close();
	           }
	    catch(Exception ae) 
	        {
	    	System.out.println(ae);
	        }
	        
		return true;
	}

	public boolean reject(String empid, String ccode) {
		// TODO Auto-generated method stub
		System.out.println(empid+""+ccode);
		 Session session  = HibernateUtils.getSession();
		 
	        try {
	            session.getTransaction().begin();
	            String hql ="update Nomination set status='rejected' where empid=:empid and ccode=:ccode";
	            Query query = session.createQuery(hql);
	            query.setParameter("empid",empid);
	            query.setParameter("ccode", ccode);
	            System.out.print(query.executeUpdate());
	            session.getTransaction().commit();
	            session.close();
	           }
	    catch(Exception ae) 
	        {
	    	System.out.println(ae);
	        }
		return true;
	}

	public boolean insertCourse(String empid, String empName, String course, String TierLevel, String mobileNumber) {
		// TODO Auto-generated method stub
		System.out.println(empid+" "+empName+" "+course);
		Session session  = null;
		 Transaction transaction=null;
		 Courses course_data=new Courses(empid,empName, course,TierLevel,mobileNumber);
		    try {
		      session =HibernateUtils.getSession();
		      transaction=session.beginTransaction();
		      session.save(course_data);
		      transaction.commit();
		    } catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		      if (session != null) {
		        session.close();
		      }
		    }
		return true;
	}
}
