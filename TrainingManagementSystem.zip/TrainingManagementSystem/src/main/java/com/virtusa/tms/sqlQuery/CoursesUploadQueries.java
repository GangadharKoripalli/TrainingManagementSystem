package com.virtusa.tms.sqlQuery;

public interface CoursesUploadQueries {
	public static final String postCourse="insert into courses(empId,empName,course,tierLevel,mobileNumber) values(?,?,?,?,?)";
	public static final String viewCourse="select * from courses";
}
