package com.virtusa.tms.daoimpl;
import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Id;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.tms.dao.EmployeeDao;
import com.virtusa.tms.hibernateUtils.HibernateUtils;
import com.virtusa.tms.model.Course;
import com.virtusa.tms.model.Courses;
import com.virtusa.tms.model.Nomination;
import com.virtusa.tms.model.Venue;

@Repository(value="EmployeeDao")
public class EmployeeDaoimpl implements EmployeeDao {
	
	//@Autowired
	  private SessionFactory sessionFactory;
	public boolean enroll(String empid, String ccode, String cname,String empname) {
		// TODO Auto-generated method stub
		//String sqlQuery = "insert into nomination(empid,ccode,cname,status) values(?,?,?,?)";
		 Session session  = null;
		 Transaction transaction=null;
		 String status="pending";
		 Nomination data= new Nomination(empid, ccode, cname, status, empname);
		    try {
		      session =HibernateUtils.getSession();
		      transaction=session.beginTransaction();
		      session.save(data);
		      transaction.commit();
		    } catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		      if (session != null) {
		        session.close();
		      }
		    }
		return true;
	}
	
	public boolean cancelEnrollment(String empid,String ccode) {
		Transaction transaction=null;
        System.out.println(empid);
        Session session  = HibernateUtils.getSession();
        transaction=session.beginTransaction();
        Query q=session.createQuery("delete from Nomination where empid=:empid and ccode=:ccode");
        q.setParameter("empid", empid);
        q.setParameter("ccode", ccode);
        q.executeUpdate();
        transaction.commit();
        return true;  
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Nomination> getStatus(String empid) {
		// TODO Auto-generated method stub
		Session session =HibernateUtils.getSession();
		String SQL_QUERY =" from Nomination where empid=:empid";
		Query query = session.createQuery(SQL_QUERY);
		query.setParameter("empid", empid);
		ArrayList<Nomination> list = (ArrayList<Nomination>) query.list();
		session.close();
		return list;
	}

	public ArrayList<Course> viewCourse() {
		// TODO Auto-generated method stub
		Session session  = HibernateUtils.getSession();
		String SQL_QUERY ="from Course order by ccode";
		Query query = session.createQuery(SQL_QUERY);
		ArrayList<Course> list = (ArrayList<Course>) query.list();
		session.close();
		return list;
	}
	public boolean insertCourse(String empid, String empName, String course, String TierLevel, String mobileNumber) {
		// TODO Auto-generated method stub
		System.out.println(empid+" "+empName+" "+course);
		Session session  = null;
		 Transaction transaction=null;
		 Courses course_data=new Courses(empid,empName, course,TierLevel,mobileNumber);
		    try {
		      session =HibernateUtils.getSession();
		      transaction=session.beginTransaction();
		      session.save(course_data);
		      transaction.commit();
		    } catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		      if (session != null) {
		        session.close();
		      }
		    }
		return true;
	}

	public ArrayList<Nomination> enrolledCourses(String empid) {
		Session session =HibernateUtils.getSession();
		String SQL_QUERY =" from Nomination where empid=:empid";
		Query query = session.createQuery(SQL_QUERY);
		query.setParameter("empid", empid);
		ArrayList<Nomination> list = (ArrayList<Nomination>) query.list();
		session.close();
		return list;
	}
}
