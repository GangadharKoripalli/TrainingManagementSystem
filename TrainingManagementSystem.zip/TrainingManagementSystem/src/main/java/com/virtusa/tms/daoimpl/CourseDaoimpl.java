package com.virtusa.tms.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.tms.dao.CourseDao;
import com.virtusa.tms.model.Course;
import com.virtusa.tms.sqlQuery.CourseQueries;
@Repository
public class CourseDaoimpl implements CourseDao {
	//@Autowired
	//  private SessionFactory sessionFactory;
	public boolean insertCourse(Course course) {
		
		Connection con = null;
		con = JdbcConnection.getConnection();
		// String query="insert into course values(?,?,?,?,?)";

		try {
			PreparedStatement pst = con.prepareStatement(CourseQueries.insertCourse);
			pst.setString(1, course.getCcode());
			pst.setString(2, course.getCname());
			pst.setString(3, course.getClevel());
			pst.setString(4, course.getCvenue());
			pst.setString(5, course.getCdate());
			int rec = pst.executeUpdate();
			PreparedStatement ps = con.prepareStatement("commit");
			ps.executeUpdate();
			if (rec == 1) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return false;
		}

		return false;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<Course> viewCourse() {
		Session session = sessionFactory.openSession();
		String SQL_QUERY ="from course order by ccode";
		Query query = session.createQuery(SQL_QUERY);
		ArrayList<Course> list = (ArrayList<Course>) query.list();
		session.close();
		return list;
	}

	public boolean deleteCourse(String cCode) {

		Connection con = null;
		con = JdbcConnection.getConnection();
		// String query="delete from course where ccode=? ";
		try {
			PreparedStatement pst = con.prepareStatement(CourseQueries.deleteCourse);
			pst.setString(1, cCode);
			int rec = pst.executeUpdate();
			if (rec == 1) {
				return true;

			}
			// String q="commit";
			PreparedStatement ps = con.prepareStatement("commit");
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return false;
		}
		return false;
	}

}
