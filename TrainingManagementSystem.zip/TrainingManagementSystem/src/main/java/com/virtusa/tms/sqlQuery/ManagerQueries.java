package com.virtusa.tms.sqlQuery;

public interface ManagerQueries {
	public static final String status="select * from nomination where status=?";
	public static final String approve="update nomination set status='accepted' where empid=? and ccode=?";
	public static final String reject="update nomination set status='rejected' where empid=? and ccode=?";
}
