/**
 * 
 */
package com.virtusa.tms.dao;

import java.util.ArrayList;

import com.virtusa.tms.model.Courses;

/**
 * @author sheshareddy
 *
 */
public interface PostCourseDao {
	public boolean postCourse(String empId, String empName, String courseName,String tierLevel,String number);
	public ArrayList<Courses> viewCourse();
}
