package com.virtusa.tms.daoimpl;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.tms.dao.PostCourseDao;
import com.virtusa.tms.model.Courses;
import com.virtusa.tms.model.Nomination;
@Repository
public class PostCourseDaoimpl implements PostCourseDao {
	//@Autowired
	  private SessionFactory sessionFactory;
	public boolean postCourse(String empId, String empName, String courseName,String tierLevel,String mobileNumber) {
		// TODO Auto-generated method stub
		//String sqlQuery = "insert into courses(empId,empName,course,tierLevel,mobileNumber) values(?,?,?,?,?)";
		Session session=sessionFactory.getCurrentSession();
		session.beginTransaction();
        //Add new Employee object
        Courses emp = new Courses();
        emp.setEmpid(empId);;
        emp.setEmpName(empName);
        emp.setCourse(courseName);
        emp.setTierLevel(tierLevel);
        emp.setMobileNumber(mobileNumber);
        //Save the employee in database
        session.save(emp);
        //Commit the transaction
        session.getTransaction().commit();
		session.close();
		return true;
	}

	public ArrayList<Courses> viewCourse() {
		Connection con=null;
		con=JdbcConnection.getConnection();
		//String query="select * from courses";
		ArrayList<Courses> ucList=new ArrayList<Courses>();
		try {
			PreparedStatement pst=con.prepareStatement(CoursesUploadQueries.viewCourse);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String empid=rs.getString(1);				
				String empName=rs.getString(2);
				String course=rs.getString(3);
				String tierLevel=rs.getString(4);
				String mobileNumber=rs.getString(5);
				Courses courses=new Courses(empid,empName,course,tierLevel,mobileNumber);
				ucList.add(courses);
				
			}
			PreparedStatement ps=con.prepareStatement("commit");
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ucList;
	}
	

}
