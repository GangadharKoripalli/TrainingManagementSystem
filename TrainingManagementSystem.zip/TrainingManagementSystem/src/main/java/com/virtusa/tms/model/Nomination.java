package com.virtusa.tms.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "nomination")
public class Nomination implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String empid;
	@Id
	private String ccode;
	@Column
	private String cName;
	@Column
	private String status;
	@Column
	private String empName;
	public Nomination() {
		super();
	}
	public Nomination(String empid, String ccode, String cName, String status,String empName) {
		super();
		this.empid = empid;
		this.ccode = ccode;
		this.empName = empName;
		this.cName = cName;
		this.status=status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Id
	@Column
	public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	@Id
	@Column
	public String getCcode() {
		return ccode;
	}
	public void setCcode(String ccode) {
		this.ccode = ccode;
	}
	@Column
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Column
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	@Column
	public String getStatus() {
		return status;
	}
	@Override
	public String toString() {
		return "Employee[empid=" + empid + ", ccode=" + ccode + ", empName=" + empName + ", cName=" + cName
				+ ", status=" + status + "]";
	}
	
}
